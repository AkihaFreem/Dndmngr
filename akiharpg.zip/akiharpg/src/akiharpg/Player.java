package akiharpg;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * 
 */
public class Player extends Personagem {
    Random rand = new Random();
    private String allignment, description;
    private Classes gender, classe;
    private int level, xpNext, xpPrevious, hpDiceSize, money;
    boolean hasStick;

    //------------------------------Getters---------------------------------
    
    public String getAllignment() {
        return allignment;
    }

    public String getDescription() {
        return description;
    }

    public Classes getGender() {
        return gender;
    }

    public Classes getClasse() {
        return classe;
    }

    public int getLevel() {
        return level;
    }

    public int getXpNext() {
        return xpNext;
    }

    public int getXpPrevious() {
        return xpPrevious;
    }

    public int getHpDiceSize() {
        return hpDiceSize;
    }

    public int getMoney() {
        return money;
    }
    
    //----------------------------------Getters Especiais------------------------------------
    
      public String getClasseString() {
        Classes c = this.classe;
        Classes g = this.gender;
        String s = new String();
        switch(c){
            case FIGHTER:
                if(g==Classes.MALE)
                    s = "Guerreiro";
                if(g==Classes.FEMALE)
                    s = "Guerreira";
                break;
            case CLERIC:
                if(g==Classes.MALE)
                    s = "Clérigo";
                if(g==Classes.FEMALE)
                    s = "Clériga";
                break;
            case RANGER:
                if(g==Classes.MALE)
                    s = "Ladino";
                if(g==Classes.FEMALE)
                    s = "Ladina";
                break;
            case WIZARD:
                if(g==Classes.MALE)
                    s = "Mago";
                if(g==Classes.FEMALE)
                    s = "Bruxa";
                break;
            default:
                s = "<null> Erro em Player.getClasseString()";
                break;
        }
        return s;
    }

    public String getGenderString() {
        Classes g = this.gender;
        String s;
        switch (g){
            case MALE:
                s = "Masculino";
                break;
            case FEMALE:
                s = "Feminino";
                break;
            default:
                s ="<null> Erro em Player.getGenderString()";
                break;
        }
        return s;
    }

    //---------------------------------Construtor----------------------------------
    
    /**
     * Construtor da classe Player. Este método só é executado por JFinsertPlayerWindow.tryCreatePlayer() se ele tornar 'ok'.
     * @param INname
     * @param INgender
     * @param INdescription
     * @param INclass
     * @param INallignment
     * @param INstr
     * @param INcon
     * @param INdex
     * @param INynt
     * @param INwis
     * @param INcha 
     */
    public Player(String INname, Classes INgender, String INdescription, Classes INclass, String INallignment, int INstr, int INcon, int INdex, int INynt, int INwis, int INcha)
    {
        //Construindo os atriibutos que vêm de parâmetros
        name = INname; 
        gender = INgender;
        description = INdescription;
        classe = INclass;
        allignment = INallignment;
        System.out.println("Alinhamento obtido no construtor: "+allignment);
        str = INstr; con = INcon; dex = INdex; ynt = INynt; wis = INwis; cha = INcha;
        hasStick = false;
        //Construindo os demais atributos
        level=1; xp=0; xpPrevious=0; xpNext=300; money=0;
        AC = 10+Personagem.getMod(dex); //O Armor Class é 10 + modificador de destreza
        //Construindo o HP
        switch(classe)
        {
            //O HP do Player é igual ao seu dado de vida máximo + modificador de constituição
            case FIGHTER:
                hpDiceSize=10;
                break;
            case RANGER:
                hpDiceSize=8;
                break;
            case CLERIC:
                hpDiceSize=8;
                break;
            case WIZARD:
                hpDiceSize=6;
                break;
            default:
                JOptionPane.showMessageDialog(null, "Erro: excessão no construtor de Player(). A classe pode não ter sido construída corretamente.");
                break;
        }
        hp = hpMax = hpDiceSize + Personagem.getMod(con);   //O jogador começa com o máximo de HP dos seus dados de vida
        //Construindo o Hit
        hitDices=1;
        hitDicesSize=2;     //Com as mãos nuas, o Player causa apenas 1d2 de dano
        //Apenas para mostrar que foi instanciado com sucesso:
        System.out.println("Nome recebido: " + name);
        System.out.println("ClasseNome recebido: " + classe);
        System.out.println("Alinhamento: " + allignment);
        System.out.println("Descrição: " + description);
        System.out.printf("Stats: %d %d %d %d %d %d \n", str, con, dex, ynt, wis, cha);
    }
    
    /**
     * Este é um Override da função toString() para a classe Player, pois isso é necessário 
     * para mostrar o nome do player na lista da janela de jogadores.
     * @return 
     */
    @Override
    public String toString()        
    {
        return this.name;
    }
    
    //---------------------------------Métodos-------------------------------------
    
    public void giveXp(int INxp){
        this.xp+=INxp;
        Akiharpg.playersWindow.refreshSelectedPlayer(); //Atualiza as informações da janela de jogadores, ja que algo mudou
    }
    
    
    /**
     * Este é o método levelUp(), que só pode ser chamada pelo método giveXp()
     */
    public void levelUp(){
        this.xpPrevious = this.xpNext;
        this.xpNext = this.xpPrevious*3;
        this.level++;
        this.hpMax += (1+rand.nextInt(this.hpDiceSize-1))+Personagem.getMod(this.con);
        if(this.level == 3 || this.level == 6 || this.level == 9 || this.level == 12 || this.level == 15 || this.level == 18 || this.level == 20){
            this.hasStick = true;   //Coloca um stick neste jogador, pra janela de level up saber que é ele quem vai upar
            LevelUpWindow levelUpWindow = new LevelUpWindow();
            levelUpWindow.setVisible(true);
            Akiharpg.playersWindow.refreshSelectedPlayer(); //Atualiza as informações da janela de jogadores, ja que algo mudou
        }
        else{
            JOptionPane.showMessageDialog(null, this.name+" subiu pro level "+this.level+"!");
            Akiharpg.playersWindow.refreshSelectedPlayer(); //Atualiza as informações da janela de jogadores, ja que algo mudou
        }
    }
    
    /**
     * Este é o método levelUpSetStats(), que atualiza os atributos do player caso a janela
     * de aumentar atributos tenha sido invocada. Ele é invocado por ela somente.
     * @param INstr
     * @param INcon
     * @param INdex
     * @param INynt
     * @param INwis
     * @param INcha
     */
    public void levelUpSetStats(int INstr, int INcon, int INdex, int INynt, int INwis, int INcha){
        this.str+=INstr;
        this.con+=INcon;
        this.dex+=INdex;
        this.ynt+=INynt;
        this.wis+=INwis;
        this.cha+=INcha;
        this.hasStick = false;  //Elimina o stick
    }
    
    /**
     * Este é o método mayLevelUp, que retorna true caso esta instância de jogador pudar upar de level, e false se não puder
     * @return 
     */
    public boolean mayLevelUp(){
        return this.xp>=this.xpNext;        //O compilador disse que não precisava de um if/else ^^
    }
    
    public void giveMoney(int INmoney){
        this.money+=INmoney;
    }
    
    public boolean loseMoney(int INmoney){
        if(INmoney<=this.money){
            this.money-=INmoney;
            return true;
        } else {
            return false;
        }
    }
    
}
