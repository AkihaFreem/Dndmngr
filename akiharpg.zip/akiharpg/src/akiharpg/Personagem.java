package akiharpg;

/**
 *
 *
 */
public abstract class Personagem {
    String name;
    int str, con, dex, ynt, wis, cha;
    int hitDices, hitDicesSize, AC;
    int xp, hp, hpMax;

    //-------------------------------Getters----------------------------------
    
    public String getName() {
        return name;
    }

    public int getStr() {
        return str;
    }

    public int getCon() {
        return con;
    }

    public int getDex() {
        return dex;
    }

    public int getYnt() {
        return ynt;
    }

    public int getWis() {
        return wis;
    }

    public int getCha() {
        return cha;
    }

    public int getHitDices() {
        return hitDices;
    }

    public int getHitDicesSize() {
        return hitDicesSize;
    }

    public int getAC() {
        return AC;
    }

    public int getXp() {
        return xp;
    }

    public int getHp() {
        return hp;
    }

    public int getHpMax() {
        return hpMax;
    }

    //------------------Métodos-----------------
    
    /**
     * O método getMod() retorna o modificador de um atributo qualquer
     * @param stat
     * @return 
     */
    public static int getMod(int stat)
    {
            double i = stat;    //converte int stat pra double, pq a porra da função exige double
            return (int)Math.floor((i-10)/2);   //faz o cálculo e executa um cast pra poder retornar int de novo
    }
    
    //TODO makeHit()
    //TODO tryToFleed()
}
