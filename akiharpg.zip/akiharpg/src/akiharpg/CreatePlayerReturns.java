package akiharpg;

public enum CreatePlayerReturns {
    NameNull, LowStat, HighStat, SumStat, full, slot, ok;
}
