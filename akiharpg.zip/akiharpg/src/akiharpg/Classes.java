package akiharpg;

public enum Classes {
    FIGHTER, CLERIC, RANGER, WIZARD, MALE, FEMALE;
}
