package akiharpg;
import java.util.Arrays;    //Os métodos da classe Arrays me permitem realizar determinadas funções com arrays comuns (ordenar, busca, etc)

public class Akiharpg {

    static Player[] player = new Player[6];     //Apenas cria o array que conterá os objetos player, mas nao instancia os objetos em si
    private static int i;   //Variável i de uso geral dentro dos métodos
    private static boolean playerCreated = false;   //Variável interna do método tryCreatePlayer
    static PlayersWindow playersWindow = new PlayersWindow();
    static MastersWindow mastersWindow = new MastersWindow();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        playersWindow.setVisible(true);
        mastersWindow.setVisible(true);
    }
    
    /**
     * Esta é a função tryCreatePlayer(), que recebe os parâmetros da janela de criar o jogador,
     * e cria automaticamente se os parâmetros estiverem corretos (retornando 'ok'), ou retornando
     * o tipo de erro que ocorreu, que será lidado pela própria janela de criação do jogador.
     * @param INname
     * @param INslot
     * @param INgender
     * @param INdescription
     * @param INclass
     * @param INallignment
     * @param INstr
     * @param INcon
     * @param INdex
     * @param INynt
     * @param INwis
     * @param INcha
     * @return 
     */
    public static CreatePlayerReturns tryCreatePlayer(String INname, int INslot, Classes INgender, String INdescription, Classes INclass, String INallignment, int INstr, int INcon, int INdex, int INynt, int INwis, int INcha)
    {
        if(INname.length()<=3)      //Verifica nome vazio
            return CreatePlayerReturns.NameNull;
        else if(player[INslot]!=null)   //Verifica se este slot ja está ocupado
            return CreatePlayerReturns.slot;
        else if(INstr <2 || INcon <2 || INdex <2 || INynt <2 || INwis <2 || INcha <2)   //Verifica stats menores que 2
            return CreatePlayerReturns.LowStat;
        else if(INstr >20 || INcon >20 || INdex >20 || INynt >20 || INwis >20 || INcha >20)
            return CreatePlayerReturns.HighStat;
        else if(INstr + INcon + INdex + INynt + INwis + INcha > 72)        //Verifica somatório = 27
            return CreatePlayerReturns.SumStat;
        else    //Se tudo tiver certo, tenta instanciar um novo Player
        {
            player[INslot] = new Player (INname, INgender, INdescription, INclass, INallignment, INstr, INcon, INdex, INynt, INwis, INcha);    //Finalmente instancia o novo player
            playersWindow.registerPlayer(INslot);    //Registra o player criado na lista do playersWindow
            System.out.println("Instância player["+Integer.toString(INslot)+"] criada");
            return CreatePlayerReturns.ok;     
        }
    }
    
}
