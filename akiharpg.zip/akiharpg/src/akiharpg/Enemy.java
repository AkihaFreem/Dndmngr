package akiharpg;

/**
 *
 * 
 */
public class Enemy {
    private String type;
    
    //TODO act()
}
